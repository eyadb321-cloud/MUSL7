/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        brand: {
          ink: "#0F2A33",
          DEFAULT: "#0E7C86",
          dark: "#0A5F67",
          glow: "#5CC8D0",
          light: "#E3F3F4",
          accent: "#F2A33A",
        },
        navy: { 950: "#07162A", 900: "#0B1F3A", 800: "#12294B", 700: "#1B3763" },
        surface: "#F5F7FA",
      },
      fontFamily: { sans: ["Cairo", "Segoe UI", "Tahoma", "Arial", "sans-serif"] },
      boxShadow: {
        card: "0 1px 2px rgba(11,31,58,.05), 0 4px 16px rgba(11,31,58,.04)",
        "card-hover": "0 2px 4px rgba(11,31,58,.06), 0 12px 28px rgba(11,31,58,.10)",
      },
      keyframes: {
        "page-in": { from: { opacity: "0", transform: "translateY(8px)" }, to: { opacity: "1", transform: "translateY(0)" } },
        rise: { from: { opacity: "0", transform: "translateY(12px)" }, to: { opacity: "1", transform: "translateY(0)" } },
        shimmer: { from: { transform: "translateX(-100%)" }, to: { transform: "translateX(100%)" } },
        "menu-in": { from: { opacity: "0", transform: "translateY(-6px) scale(.98)" }, to: { opacity: "1", transform: "translateY(0) scale(1)" } },
        "toast-in": { from: { opacity: "0", transform: "translateX(-16px)" }, to: { opacity: "1", transform: "translateX(0)" } },
        "toast-out": { from: { opacity: "1", transform: "translateX(0)" }, to: { opacity: "0", transform: "translateX(-16px)" } },
      },
      animation: {
        // "backwards": لا نثبّت الحالة النهائية حتى لا نعطّل تأثير الـhover (transform)
        "page-in": "page-in 280ms cubic-bezier(.22,1,.36,1) backwards",
        rise: "rise 420ms cubic-bezier(.22,1,.36,1) backwards",
        shimmer: "shimmer 1.4s ease-in-out infinite",
        "menu-in": "menu-in 160ms ease-out backwards",
        "toast-in": "toast-in 260ms cubic-bezier(.22,1,.36,1) both",
        "toast-out": "toast-out 200ms ease-in both",
      },
    },
  },
  plugins: [],
};
