import { Info } from "lucide-react";
import { useAuth } from "../features/auth/AuthContext";
import { METRICS, useDashboardMetrics } from "../features/dashboard/metrics";
import { MetricCard } from "../features/dashboard/MetricCard";
import { QuickActions } from "../features/dashboard/QuickActions";
import { RecentActivity } from "../features/dashboard/RecentActivity";
import { SystemStatusCard } from "../features/dashboard/SystemStatusCard";
import { formatLongDate, greeting } from "../lib/format";

export default function DashboardPage() {
  const { user } = useAuth();
  const states = useDashboardMetrics();

  return (
    <div className="space-y-6">
      <header className="animate-rise">
        <p className="text-sm font-medium text-slate-500">{formatLongDate()}</p>
        <h1 className="mt-1 text-2xl font-bold sm:text-3xl">
          {greeting()}، {user?.full_name}
        </h1>
        <p className="mt-1 text-sm text-slate-500">{user?.role_name_ar} — مُصلِّح | MUSL7</p>
      </header>

      <div
        role="note"
        className="flex animate-rise items-start gap-3 rounded-2xl border border-brand/15 bg-brand-light/60 p-4 text-sm leading-6 text-brand-dark"
        style={{ animationDelay: "60ms" }}
      >
        <Info className="mt-0.5 h-5 w-5 shrink-0" aria-hidden="true" />
        <p>
          النظام في مرحلة التأسيس. الأرقام التشغيلية والمالية لا تظهر قبل تفعيل وحداتها وقواعد بياناتها، ولا تُعرض أي
          أرقام تجريبية على أنها بيانات الشركة.
        </p>
      </div>

      <section aria-label="ملخص النشاط" className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
        {METRICS.map((m, i) => (
          <MetricCard key={m.id} metric={m} state={states[m.id] ?? { status: "pending" }} index={i} />
        ))}
      </section>

      <div className="grid gap-6 lg:grid-cols-3">
        <RecentActivity className="lg:col-span-2" />
        <div className="space-y-6">
          <QuickActions />
          <SystemStatusCard />
        </div>
      </div>
    </div>
  );
}
