import { ArrowRight, CheckCircle2 } from "lucide-react";
import { Link } from "react-router-dom";
import { Badge } from "../components/ui/Badge";
import { Card } from "../components/ui/Card";
import { EmptyState } from "../components/ui/EmptyState";
import { phaseLabel, type NavItem } from "../features/navigation/navItems";

export default function ModulePlaceholderPage({ item }: { item: NavItem }) {
  const Icon = item.icon;
  return (
    <div className="space-y-6">
      <header className="flex animate-rise items-center gap-4">
        <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-brand-light text-brand">
          <Icon className="h-6 w-6" aria-hidden="true" />
        </span>
        <div>
          <h1 className="text-2xl font-bold">{item.label}</h1>
          <p className="text-sm text-slate-500">{item.description}</p>
        </div>
      </header>

      <Card className="animate-rise" style={{ animationDelay: "80ms" }}>
        <EmptyState
          icon={Icon}
          title="هذه الوحدة لم تُبنَ بعد"
          description="لا توجد بيانات هنا لأن الوحدة وقاعدة بياناتها وواجهة الـAPI الخاصة بها لم تُنفَّذ بعد."
          action={<Badge tone="pending">تُفعَّل في: {phaseLabel(item.phase)}</Badge>}
        />
      </Card>

      {item.planned.length > 0 && (
        <Card className="animate-rise p-5" style={{ animationDelay: "160ms" }}>
          <h2 className="font-bold">ما سيتوفر في هذه الوحدة</h2>
          <ul className="mt-3 space-y-2">
            {item.planned.map((p) => (
              <li key={p} className="flex items-start gap-2 text-sm text-slate-600">
                <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-brand" aria-hidden="true" />
                {p}
              </li>
            ))}
          </ul>
        </Card>
      )}

      <Link
        to="/"
        className="inline-flex items-center gap-2 text-sm font-semibold text-brand transition hover:text-brand-dark"
      >
        <ArrowRight className="h-4 w-4" aria-hidden="true" />
        العودة إلى الرئيسية
      </Link>
    </div>
  );
}
