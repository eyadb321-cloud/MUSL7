import { SearchX } from "lucide-react";
import { Link } from "react-router-dom";
import { Card } from "../components/ui/Card";
import { EmptyState } from "../components/ui/EmptyState";

export default function NotFoundPage() {
  return (
    <Card>
      <EmptyState
        icon={SearchX}
        title="الصفحة غير موجودة"
        description="الرابط الذي فتحته غير صحيح أو تم نقله."
        action={
          <Link
            to="/"
            className="inline-flex rounded-lg bg-brand px-4 py-2 text-sm font-semibold text-white transition hover:bg-brand-dark active:scale-[0.97]"
          >
            العودة إلى الرئيسية
          </Link>
        }
      />
    </Card>
  );
}
