import { LogOut, X } from "lucide-react";
import { NavLink, useLocation } from "react-router-dom";
import { BRAND } from "../brand";
import { Logo } from "../components/Logo";
import { useToast } from "../components/ui/Toast";
import { useAuth } from "../features/auth/AuthContext";
import { NAV_ITEMS, isActivePath } from "../features/navigation/navItems";

const ITEM_H = 44; // h-11
const GAP = 4; // gap-1

interface Props {
  open: boolean;
  onClose: () => void;
}

export function Sidebar({ open, onClose }: Props) {
  const { pathname } = useLocation();
  const { logout } = useAuth();
  const { toast } = useToast();
  const activeIndex = NAV_ITEMS.findIndex((i) => isActivePath(i, pathname));

  const onLogout = () => {
    logout();
    toast("تم تسجيل الخروج بنجاح", "success");
  };

  return (
    <>
      <div
        aria-hidden="true"
        onClick={onClose}
        className={`fixed inset-0 z-30 bg-navy-950/50 transition-opacity duration-300 lg:hidden ${
          open ? "opacity-100" : "pointer-events-none opacity-0"
        }`}
      />
      <aside
        id="app-sidebar"
        className={`fixed inset-y-0 start-0 z-40 flex w-72 flex-col bg-navy-900 text-slate-300 transition-[transform,visibility] duration-300 ease-out lg:static lg:visible lg:w-64 lg:shrink-0 lg:translate-x-0 ${
          open ? "visible translate-x-0" : "invisible translate-x-full"
        }`}
      >
        <div className="flex h-16 items-center justify-between border-b border-white/10 px-5">
          <Logo light />
          <button
            type="button"
            onClick={onClose}
            aria-label="إغلاق القائمة"
            className="rounded-lg p-1.5 text-slate-400 transition hover:bg-white/10 hover:text-white lg:hidden"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <nav aria-label="التنقل الرئيسي" className="flex-1 overflow-y-auto px-3 py-3">
          <div className="relative flex flex-col gap-1">
            <span
              aria-hidden="true"
              className="pointer-events-none absolute inset-x-0 top-0 h-11 rounded-xl bg-white/10 transition-[transform,opacity] duration-300 ease-out before:absolute before:inset-y-2.5 before:start-0 before:w-1 before:rounded-full before:bg-brand-accent"
              style={{
                transform: `translateY(${Math.max(activeIndex, 0) * (ITEM_H + GAP)}px)`,
                opacity: activeIndex < 0 ? 0 : 1,
              }}
            />
            {NAV_ITEMS.map((item) => {
              const Icon = item.icon;
              return (
                <NavLink
                  key={item.path}
                  to={item.path}
                  end={item.path === "/"}
                  onClick={onClose}
                  className={({ isActive }) =>
                    `group relative z-10 flex h-11 items-center gap-3 rounded-xl px-4 text-sm font-semibold transition-colors duration-200 ${
                      isActive ? "text-white" : "hover:bg-white/5 hover:text-white"
                    }`
                  }
                >
                  {({ isActive }) => (
                    <>
                      <Icon
                        className={`h-5 w-5 shrink-0 transition-all duration-200 group-hover:scale-110 ${
                          isActive ? "text-brand-glow" : "text-slate-400 group-hover:text-brand-glow"
                        }`}
                        aria-hidden="true"
                      />
                      <span className="truncate">{item.label}</span>
                    </>
                  )}
                </NavLink>
              );
            })}
          </div>
        </nav>

        <div className="space-y-2 border-t border-white/10 p-3">
          <button
            type="button"
            onClick={onLogout}
            className="flex h-11 w-full items-center gap-3 rounded-xl px-4 text-sm font-semibold text-slate-300 transition duration-200 hover:bg-red-500/10 hover:text-red-200 active:scale-[0.98]"
          >
            <LogOut className="h-5 w-5" aria-hidden="true" />
            تسجيل الخروج
          </button>
          <p dir="ltr" className="px-4 text-start text-[10px] leading-4 text-slate-500">
            {BRAND.product}
          </p>
        </div>
      </aside>
    </>
  );
}
