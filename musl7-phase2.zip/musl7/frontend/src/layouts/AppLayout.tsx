import { useEffect, useRef, useState } from "react";
import { Outlet, useLocation } from "react-router-dom";
import { BRAND } from "../brand";
import { findNavItem } from "../features/navigation/navItems";
import { Sidebar } from "./Sidebar";
import { Topbar } from "./Topbar";

export default function AppLayout() {
  const [open, setOpen] = useState(false);
  const { pathname } = useLocation();
  const mainRef = useRef<HTMLElement>(null);
  const item = findNavItem(pathname);

  useEffect(() => {
    setOpen(false);
    mainRef.current?.scrollTo({ top: 0 });
  }, [pathname]);

  useEffect(() => {
    document.title = `${item ? item.label + " | " : ""}${BRAND.display}`;
  }, [item]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [open]);

  return (
    <div className="flex h-full overflow-hidden bg-surface">
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:fixed focus:start-3 focus:top-3 focus:z-50 focus:rounded-lg focus:bg-white focus:px-4 focus:py-2 focus:shadow-card-hover"
      >
        تخطي إلى المحتوى
      </a>
      <Sidebar open={open} onClose={() => setOpen(false)} />
      <div className="flex min-w-0 flex-1 flex-col">
        <Topbar onMenu={() => setOpen(true)} menuOpen={open} />
        <main id="main" ref={mainRef} tabIndex={-1} className="flex-1 overflow-y-auto focus:outline-none">
          <div key={pathname} className="mx-auto w-full max-w-7xl animate-page-in px-4 py-6 sm:px-6 lg:px-8">
            <Outlet />
          </div>
        </main>
      </div>
    </div>
  );
}
