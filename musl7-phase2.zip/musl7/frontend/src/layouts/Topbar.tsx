import { Menu } from "lucide-react";
import { useLocation } from "react-router-dom";
import { findNavItem } from "../features/navigation/navItems";
import { useBackendHealth } from "../features/system/useBackendHealth";
import { UserMenu } from "./UserMenu";

function HealthPill() {
  const { isPending, isError } = useBackendHealth();
  const tone = isPending ? "bg-slate-300" : isError ? "bg-red-500" : "bg-emerald-500";
  const text = isPending ? "جارٍ فحص الخادم" : isError ? "الخادم غير متصل" : "الخادم متصل";
  return (
    <div
      title={text}
      className="hidden items-center gap-2 rounded-full border border-slate-200 px-3 py-1 text-xs font-semibold text-slate-600 sm:flex"
    >
      <span className={`h-2 w-2 rounded-full transition-colors duration-300 ${tone}`} aria-hidden="true" />
      {text}
    </div>
  );
}

export function Topbar({ onMenu, menuOpen }: { onMenu: () => void; menuOpen: boolean }) {
  const { pathname } = useLocation();
  const item = findNavItem(pathname);
  return (
    <header className="sticky top-0 z-20 flex h-16 shrink-0 items-center gap-3 border-b border-slate-200/70 bg-white px-4 sm:px-6 lg:px-8">
      <button
        type="button"
        onClick={onMenu}
        aria-label="فتح القائمة"
        aria-controls="app-sidebar"
        aria-expanded={menuOpen}
        className="rounded-lg p-2 text-slate-600 transition hover:bg-slate-100 active:scale-95 lg:hidden"
      >
        <Menu className="h-5 w-5" />
      </button>
      <div className="min-w-0 flex-1">
        <h2 className="truncate text-lg font-bold leading-tight">{item?.label ?? "صفحة غير موجودة"}</h2>
        <p dir="ltr" className="text-start text-[11px] font-semibold tracking-widest text-brand-accent">
          MUSL7
        </p>
      </div>
      <HealthPill />
      <UserMenu />
    </header>
  );
}
