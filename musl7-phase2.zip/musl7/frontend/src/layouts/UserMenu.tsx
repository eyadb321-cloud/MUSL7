import { ChevronDown, LogOut } from "lucide-react";
import { useCallback, useRef, useState } from "react";
import { Badge } from "../components/ui/Badge";
import { useToast } from "../components/ui/Toast";
import { useAuth } from "../features/auth/AuthContext";
import { useDismiss } from "../hooks/useDismiss";

export function UserMenu() {
  const { user, logout } = useAuth();
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const close = useCallback(() => setOpen(false), []);
  useDismiss(ref, open, close);

  if (!user) return null;
  const initial = user.full_name.trim().charAt(0) || "م";

  const onLogout = () => {
    logout();
    toast("تم تسجيل الخروج بنجاح", "success");
  };

  return (
    <div ref={ref} className="relative">
      <button
        type="button"
        aria-haspopup="menu"
        aria-expanded={open}
        onClick={() => setOpen((o) => !o)}
        className="flex items-center gap-3 rounded-xl py-1.5 pe-2 ps-2 transition duration-200 hover:bg-slate-100 active:scale-[0.98] sm:pe-3"
      >
        <span className="flex h-9 w-9 items-center justify-center rounded-full bg-brand font-bold text-white">{initial}</span>
        <span className="hidden text-start sm:block">
          <span className="block text-sm font-semibold leading-tight">{user.full_name}</span>
          <span className="block text-xs text-slate-500">{user.role_name_ar}</span>
        </span>
        <ChevronDown
          className={`hidden h-4 w-4 text-slate-400 transition-transform duration-200 sm:block ${open ? "rotate-180" : ""}`}
          aria-hidden="true"
        />
      </button>

      {open && (
        <div
          role="menu"
          className="absolute end-0 top-full z-30 mt-2 w-64 origin-top animate-menu-in rounded-2xl border border-slate-200 bg-white p-2 shadow-card-hover"
        >
          <div className="px-3 py-2">
            <p className="font-semibold">{user.full_name}</p>
            <p dir="ltr" className="text-start text-xs text-slate-500">
              @{user.username}
            </p>
            <div className="mt-2">
              <Badge tone="brand">{user.role_name_ar}</Badge>
            </div>
          </div>
          <div className="my-1 border-t border-slate-100" />
          <button
            type="button"
            role="menuitem"
            onClick={onLogout}
            className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium text-red-600 transition hover:bg-red-50 active:scale-[0.98]"
          >
            <LogOut className="h-4 w-4" aria-hidden="true" />
            تسجيل الخروج
          </button>
        </div>
      )}
    </div>
  );
}
