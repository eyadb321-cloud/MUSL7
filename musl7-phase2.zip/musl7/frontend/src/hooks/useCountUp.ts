import { useEffect, useRef, useState } from "react";
import { prefersReducedMotion } from "../lib/motion";

/** عدّاد رقمي سلس لقيم حقيقية فقط. يتخطى الحركة إذا فضّل المستخدم تقليلها. */
export function useCountUp(target: number, duration = 900): number {
  const [value, setValue] = useState(0);
  const current = useRef(0);

  useEffect(() => {
    if (prefersReducedMotion() || current.current === target) {
      current.current = target;
      setValue(target);
      return;
    }
    const from = current.current;
    const t0 = performance.now();
    let raf = 0;
    const tick = (now: number) => {
      const p = Math.min(1, (now - t0) / duration);
      const eased = 1 - Math.pow(1 - p, 3);
      current.current = from + (target - from) * eased;
      setValue(current.current);
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [target, duration]);

  return value;
}
