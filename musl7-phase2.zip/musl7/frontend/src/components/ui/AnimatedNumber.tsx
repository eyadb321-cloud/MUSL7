import { useCountUp } from "../../hooks/useCountUp";
import { formatNumber } from "../../lib/format";

/** يُستخدم لقيم حقيقية فقط (تأتي من الـAPI). لا يُستخدم مع القيم المعلّقة. */
export function AnimatedNumber({ value, format = formatNumber }: { value: number; format?: (n: number) => string }) {
  const v = useCountUp(value);
  return (
    <span className="tabular-nums" aria-label={format(value)}>
      {format(Math.round(v))}
    </span>
  );
}
