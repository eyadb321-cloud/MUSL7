import { useQuery } from "@tanstack/react-query";
import { api } from "../../services/api";
import type { HealthResponse } from "../../types/system";

/** فحص حقيقي لـ GET /api/health (الموجود في Phase 1). */
export function useBackendHealth() {
  return useQuery({
    queryKey: ["backend-health"],
    queryFn: () => api<HealthResponse>("/health"),
    refetchInterval: 60_000,
  });
}
