import {
  BarChart3,
  CalendarCheck,
  ClipboardList,
  FileText,
  HardHat,
  LayoutDashboard,
  MessageCircle,
  Package,
  Settings,
  ShieldCheck,
  Store,
  UserCog,
  Users,
  Wallet,
  type LucideIcon,
} from "lucide-react";

export interface NavItem {
  path: string;
  label: string;
  icon: LucideIcon;
  /** المرحلة التي تُفعَّل فيها الوحدة. null = غير مجدولة بعد */
  phase: number | null;
  description: string;
  planned: string[];
}

export const NAV_ITEMS: NavItem[] = [
  { path: "/", label: "الرئيسية", icon: LayoutDashboard, phase: 2, description: "نظرة عامة على نشاط الشركة.", planned: [] },
  {
    path: "/requests", label: "طلبات الصيانة", icon: ClipboardList, phase: 3,
    description: "استقبال طلبات الصيانة ومتابعتها من الاستلام حتى الإغلاق.",
    planned: ["حالات الطلب من الجديد حتى الإغلاق مع سجل لكل تغيير", "إسناد الطلب لصنايعي", "فصل حالة الدفع عن حالة الطلب"],
  },
  {
    path: "/customers", label: "العملاء", icon: Users, phase: 3,
    description: "إدارة بيانات العملاء وسجل طلباتهم.",
    planned: ["بيانات العملاء بدون تكرار (برقم الهاتف)", "سجل الطلبات والمحادثات لكل عميل"],
  },
  {
    path: "/technicians", label: "الصنايعية", icon: HardHat, phase: 3,
    description: "إدارة الصنايعية المتعاونين وتخصصاتهم.",
    planned: ["التخصصات والمهارات والمناطق", "التقييم والمواعيد المتاحة وسجل الأعمال"],
  },
  {
    path: "/visits", label: "المعاينات", icon: CalendarCheck, phase: 4,
    description: "جدولة المعاينات والزيارات وتسجيل نتائجها.",
    planned: ["جدولة الزيارات مع العميل والصنايعي", "تسجيل نتيجة المعاينة"],
  },
  {
    path: "/quotations", label: "عروض الأسعار", icon: FileText, phase: 4,
    description: "إنشاء عروض الأسعار ومتابعة موافقة العملاء.",
    planned: ["بنود العمالة والخامات والخصم", "اعتماد السعر يدويًا من الموظف المسؤول"],
  },
  {
    path: "/suppliers", label: "الموردون", icon: Store, phase: 3,
    description: "إدارة محلات وموردي الخامات.",
    planned: ["بيانات الموردين وأنواع الخامات", "سجل المشتريات من كل مورد"],
  },
  {
    path: "/materials", label: "الخامات", icon: Package, phase: 4,
    description: "شراء الخامات المطلوبة لكل طلب.",
    planned: ["طلبات شراء الخامات المرتبطة بالطلبات", "الكميات والأسعار وصور الفواتير"],
  },
  {
    path: "/accounts", label: "الحسابات", icon: Wallet, phase: 5,
    description: "الإيرادات والمصروفات ومستحقات الصنايعية بالجنيه المصري.",
    planned: ["عمليات مالية مرتبطة بالطلبات", "مستحقات الصنايعية القابلة للضبط"],
  },
  {
    path: "/conversations", label: "المحادثات", icon: MessageCircle, phase: 7,
    description: "صندوق محادثات واتساب مع العملاء.",
    planned: ["متابعة الرسائل الواردة والصادرة", "تحويل المحادثة من المساعد إلى موظف"],
  },
  {
    path: "/warranties", label: "الضمانات", icon: ShieldCheck, phase: 5,
    description: "تسجيل الضمانات والشكاوى المرتبطة بها.",
    planned: ["مدد وشروط ضمان قابلة للتغيير", "الشكاوى المرتبطة بكل ضمان"],
  },
  {
    path: "/reports", label: "التقارير", icon: BarChart3, phase: 5,
    description: "تقارير الطلبات والأداء والأرباح.",
    planned: ["تقارير الطلبات والإيرادات والمصروفات", "أرقام فعلية فقط من البيانات المسجلة"],
  },
  {
    path: "/users", label: "المستخدمون", icon: UserCog, phase: null,
    description: "إدارة حسابات الموظفين وأدوارهم.",
    planned: ["إنشاء حسابات الموظفين", "تعديل الأدوار والصلاحيات"],
  },
  {
    path: "/settings", label: "الإعدادات", icon: Settings, phase: null,
    description: "إعدادات النظام العامة.",
    planned: ["ضبط الضمان والمستحقات", "إعدادات التكامل"],
  },
];

export const phaseLabel = (phase: number | null) => (phase ? `المرحلة ${phase}` : "مرحلة لاحقة");

export function isActivePath(item: NavItem, pathname: string): boolean {
  return item.path === "/" ? pathname === "/" : pathname === item.path || pathname.startsWith(item.path + "/");
}

export const findNavItem = (pathname: string) => NAV_ITEMS.find((i) => isActivePath(i, pathname));
