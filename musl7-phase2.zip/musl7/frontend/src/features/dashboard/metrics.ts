import { ClipboardList, Hammer, HardHat, CircleCheckBig, FilePlus2, TrendingUp, Users, Wallet, ReceiptText } from "lucide-react";
import type { MetricDef, MetricState } from "./types";

export const METRICS: MetricDef[] = [
  { id: "requests_total", label: "إجمالي الطلبات", icon: ClipboardList, kind: "count", module: "طلبات الصيانة", phase: 3, tone: "navy" },
  { id: "requests_new", label: "الطلبات الجديدة", icon: FilePlus2, kind: "count", module: "طلبات الصيانة", phase: 3, tone: "orange" },
  { id: "requests_in_progress", label: "قيد التنفيذ", icon: Hammer, kind: "count", module: "طلبات الصيانة", phase: 3, tone: "teal" },
  { id: "requests_completed", label: "الطلبات المكتملة", icon: CircleCheckBig, kind: "count", module: "طلبات الصيانة", phase: 3, tone: "teal" },
  { id: "customers", label: "العملاء", icon: Users, kind: "count", module: "العملاء", phase: 3, tone: "navy" },
  { id: "technicians_active", label: "الصنايعية النشطون", icon: HardHat, kind: "count", module: "الصنايعية", phase: 3, tone: "slate" },
  { id: "revenue", label: "الإيرادات", icon: Wallet, kind: "currency", module: "الحسابات", phase: 5, tone: "teal" },
  { id: "expenses", label: "المصروفات", icon: ReceiptText, kind: "currency", module: "الحسابات", phase: 5, tone: "orange" },
  { id: "net_profit", label: "صافي الربح الفعلي", icon: TrendingUp, kind: "currency", module: "الحسابات", phase: 5, tone: "navy" },
];

/**
 * نقطة الربط المستقبلية بالـAPI. حاليًا لا توجد واجهات API لهذه الأرقام، لذلك لا نُرجع أي قيم
 * (كل المؤشرات تظهر "قيد التفعيل"). عند بناء الوحدات تُستبدل بـuseQuery يرجع MetricState لكل id.
 */
export function useDashboardMetrics(): Record<string, MetricState> {
  return {};
}
