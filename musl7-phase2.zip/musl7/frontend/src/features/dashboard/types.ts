import type { LucideIcon } from "lucide-react";

export type MetricState =
  | { status: "loading" }
  | { status: "error" }
  | { status: "pending" } // الوحدة/الـAPI غير موجودة بعد: لا يوجد رقم حقيقي
  | { status: "ready"; value: number };

export type MetricTone = "teal" | "navy" | "orange" | "slate";

export interface MetricDef {
  id: string;
  label: string;
  icon: LucideIcon;
  kind: "count" | "currency";
  /** اسم الوحدة التي ستوفر هذا الرقم */
  module: string;
  phase: number;
  tone: MetricTone;
}
