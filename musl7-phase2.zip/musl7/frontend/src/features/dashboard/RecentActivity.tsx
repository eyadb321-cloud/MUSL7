import { History } from "lucide-react";
import { Card } from "../../components/ui/Card";
import { EmptyState } from "../../components/ui/EmptyState";

export function RecentActivity({ className = "" }: { className?: string }) {
  return (
    <Card className={`animate-rise ${className}`} style={{ animationDelay: "450ms" }}>
      <div className="flex items-center gap-2 border-b border-slate-100 px-5 py-4">
        <History className="h-5 w-5 text-brand" aria-hidden="true" />
        <h3 className="font-bold">آخر العمليات</h3>
      </div>
      {/* سجل النشاط محفوظ في جدول activity_logs لكن لا توجد واجهة API لعرضه بعد، فلا نعرض أي بيانات. */}
      <EmptyState
        icon={History}
        title="سجل العمليات غير متاح بعد"
        description="ستظهر هنا آخر العمليات على النظام بعد ربط سجل النشاط بواجهة API. لا تُعرض بيانات تجريبية."
      />
    </Card>
  );
}
