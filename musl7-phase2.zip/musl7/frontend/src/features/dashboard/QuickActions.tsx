import { ClipboardPlus, FilePlus2, HardHat, UserPlus, Wallet } from "lucide-react";
import { Badge } from "../../components/ui/Badge";
import { Card } from "../../components/ui/Card";
import { phaseLabel } from "../navigation/navItems";

const ACTIONS = [
  { label: "طلب صيانة جديد", icon: ClipboardPlus, phase: 3 },
  { label: "إضافة عميل", icon: UserPlus, phase: 3 },
  { label: "إضافة صنايعي", icon: HardHat, phase: 3 },
  { label: "عرض سعر جديد", icon: FilePlus2, phase: 4 },
  { label: "تسجيل عملية مالية", icon: Wallet, phase: 5 },
];

export function QuickActions() {
  return (
    <Card className="animate-rise p-5" style={{ animationDelay: "500ms" }}>
      <h3 className="font-bold">إجراءات سريعة</h3>
      <p className="mt-1 text-xs text-slate-500">تُفعَّل كل إجراء مع وحدته.</p>
      <ul className="mt-4 space-y-2">
        {ACTIONS.map(({ label, icon: Icon, phase }) => (
          <li key={label}>
            <button
              type="button"
              disabled
              title={`متاح في ${phaseLabel(phase)}`}
              className="flex w-full cursor-not-allowed items-center gap-3 rounded-xl border border-slate-200 px-3 py-2.5 text-start text-sm font-medium text-slate-400"
            >
              <Icon className="h-4 w-4 shrink-0" aria-hidden="true" />
              <span className="flex-1">{label}</span>
              <Badge>{phaseLabel(phase)}</Badge>
            </button>
          </li>
        ))}
      </ul>
    </Card>
  );
}
