import { Server } from "lucide-react";
import type { ReactNode } from "react";
import { Badge } from "../../components/ui/Badge";
import { Card } from "../../components/ui/Card";
import { ErrorState } from "../../components/ui/ErrorState";
import { Skeleton } from "../../components/ui/Skeleton";
import { formatTime } from "../../lib/format";
import { useBackendHealth } from "../system/useBackendHealth";

function Row({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-3 text-sm">
      <span className="text-slate-500">{label}</span>
      <span className="font-semibold">{children}</span>
    </div>
  );
}

export function SystemStatusCard() {
  const q = useBackendHealth();
  return (
    <Card className="animate-rise" style={{ animationDelay: "550ms" }}>
      <div className="flex items-center gap-2 border-b border-slate-100 px-5 py-4">
        <Server className="h-5 w-5 text-brand" aria-hidden="true" />
        <h3 className="font-bold">حالة النظام</h3>
      </div>
      <div className="min-h-[132px] p-5">
        {q.isPending && (
          <div className="space-y-3">
            <Skeleton className="h-5 w-full" />
            <Skeleton className="h-5 w-4/5" />
            <Skeleton className="h-5 w-3/5" />
          </div>
        )}
        {q.isError && (
          <ErrorState
            message="تعذر الاتصال بالخادم. تأكد من تشغيل الـBackend."
            onRetry={() => void q.refetch()}
            retrying={q.isFetching}
          />
        )}
        {q.isSuccess && (
          <div className="animate-rise space-y-3">
            <Row label="الخادم (Backend)">
              <Badge tone={q.data.status === "ok" ? "success" : "danger"}>{q.data.status === "ok" ? "متصل" : "غير سليم"}</Badge>
            </Row>
            <Row label="التطبيق">
              <span dir="ltr">{q.data.app}</span>
            </Row>
            <Row label="آخر فحص">{formatTime(q.dataUpdatedAt)}</Row>
            <Row label="المرحلة الحالية">المرحلة 2</Row>
          </div>
        )}
      </div>
    </Card>
  );
}
