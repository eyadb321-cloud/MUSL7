import { AnimatedNumber } from "../../components/ui/AnimatedNumber";
import { Badge } from "../../components/ui/Badge";
import { Card } from "../../components/ui/Card";
import { Skeleton } from "../../components/ui/Skeleton";
import { formatEGP, formatNumber } from "../../lib/format";
import { phaseLabel } from "../navigation/navItems";
import type { MetricDef, MetricState, MetricTone } from "./types";

const TONES: Record<MetricTone, string> = {
  teal: "bg-brand-light text-brand",
  navy: "bg-navy-900/5 text-navy-800",
  orange: "bg-brand-accent/15 text-amber-700",
  slate: "bg-slate-100 text-slate-600",
};

interface Props {
  metric: MetricDef;
  state: MetricState;
  index: number;
}

export function MetricCard({ metric, state, index }: Props) {
  const Icon = metric.icon;
  const format = metric.kind === "currency" ? formatEGP : formatNumber;

  return (
    <Card
      className="animate-rise p-5 transition duration-200 hover:-translate-y-0.5 hover:shadow-card-hover"
      style={{ animationDelay: `${Math.min(index, 8) * 50}ms` }}
    >
      <div className="flex items-center gap-3">
        <span className={`flex h-10 w-10 items-center justify-center rounded-xl ${TONES[metric.tone]}`}>
          <Icon className="h-5 w-5" aria-hidden="true" />
        </span>
        <h3 className="text-sm font-semibold text-slate-600">{metric.label}</h3>
      </div>

      <div className="mt-4 flex h-10 items-center">
        {state.status === "loading" && <Skeleton className="h-8 w-28" />}
        {state.status === "error" && <span className="text-sm font-medium text-red-600">تعذر تحميل القيمة</span>}
        {state.status === "ready" && (
          <span className="text-3xl font-bold">
            <AnimatedNumber value={state.value} format={format} />
          </span>
        )}
        {state.status === "pending" && (
          <div className="flex items-center gap-2">
            <span className="text-2xl font-bold text-slate-300" aria-hidden="true">
              —
            </span>
            <Badge tone="pending">قيد التفعيل</Badge>
          </div>
        )}
      </div>

      <p className="mt-3 text-xs leading-5 text-slate-500">
        {state.status === "pending"
          ? `تُعرض بعد تفعيل وحدة ${metric.module} (${phaseLabel(metric.phase)})`
          : metric.module}
      </p>
    </Card>
  );
}
