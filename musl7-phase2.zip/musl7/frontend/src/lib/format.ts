const nf = new Intl.NumberFormat("ar-EG");
const cf = new Intl.NumberFormat("ar-EG", { style: "currency", currency: "EGP", maximumFractionDigits: 0 });

export const formatNumber = (n: number) => nf.format(n);
export const formatEGP = (n: number) => cf.format(n);

export function greeting(d = new Date()): string {
  const h = d.getHours();
  if (h < 5) return "مساء الخير";
  if (h < 12) return "صباح الخير";
  if (h < 17) return "أهلاً بك";
  return "مساء الخير";
}

export const formatLongDate = (d = new Date()) =>
  new Intl.DateTimeFormat("ar-EG", { weekday: "long", day: "numeric", month: "long", year: "numeric" }).format(d);

export const formatTime = (ms: number) =>
  new Intl.DateTimeFormat("ar-EG", { hour: "numeric", minute: "2-digit" }).format(new Date(ms));
