import { Route, Routes } from "react-router-dom";
import ProtectedRoute from "./features/auth/ProtectedRoute";
import { NAV_ITEMS } from "./features/navigation/navItems";
import AppLayout from "./layouts/AppLayout";
import DashboardPage from "./pages/DashboardPage";
import LoginPage from "./pages/LoginPage";
import ModulePlaceholderPage from "./pages/ModulePlaceholderPage";
import NotFoundPage from "./pages/NotFoundPage";

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<LoginPage />} />
      <Route element={<ProtectedRoute />}>
        <Route element={<AppLayout />}>
          <Route index element={<DashboardPage />} />
          {NAV_ITEMS.filter((i) => i.path !== "/").map((i) => (
            <Route key={i.path} path={i.path} element={<ModulePlaceholderPage item={i} />} />
          ))}
          <Route path="*" element={<NotFoundPage />} />
        </Route>
      </Route>
    </Routes>
  );
}
