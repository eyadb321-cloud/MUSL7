import { BRAND } from "../brand";

export function Logo({ light = false }: { light?: boolean }) {
  return (
    <div className="flex items-center gap-3">
      <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-brand text-2xl font-bold text-white shadow">
        م
      </div>
      <div className="leading-tight">
        <div className={`text-xl font-bold ${light ? "text-white" : "text-brand-ink"}`}>{BRAND.ar}</div>
        <div dir="ltr" className="text-xs font-semibold tracking-widest text-brand-accent">
          {BRAND.en}
        </div>
      </div>
    </div>
  );
}
