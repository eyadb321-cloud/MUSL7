export interface User {
  id: number;
  username: string;
  full_name: string;
  role_code: string;
  role_name_ar: string;
}
export interface TokenResponse {
  access_token: string;
  token_type: string;
  user: User;
}
