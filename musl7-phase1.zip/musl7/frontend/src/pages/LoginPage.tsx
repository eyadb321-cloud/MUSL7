import { zodResolver } from "@hookform/resolvers/zod";
import { AlertCircle, Eye, EyeOff, Loader2 } from "lucide-react";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { Navigate, useNavigate } from "react-router-dom";
import { z } from "zod";
import { BRAND } from "../brand";
import { Logo } from "../components/Logo";
import { useAuth } from "../features/auth/AuthContext";

const schema = z.object({
  username: z.string().trim().min(3, "اسم المستخدم 3 أحرف على الأقل"),
  password: z.string().min(1, "أدخل كلمة المرور"),
});
type Form = z.infer<typeof schema>;

export default function LoginPage() {
  const { user, login } = useAuth();
  const navigate = useNavigate();
  const [error, setError] = useState<string | null>(null);
  const [show, setShow] = useState(false);
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<Form>({ resolver: zodResolver(schema) });

  if (user) return <Navigate to="/" replace />;

  const onSubmit = async (v: Form) => {
    setError(null);
    try {
      await login(v.username, v.password);
      navigate("/", { replace: true });
    } catch (e) {
      setError(e instanceof Error ? e.message : "تعذر تسجيل الدخول");
    }
  };

  const field = "w-full rounded-lg border border-slate-300 bg-white px-3 py-2.5 outline-none focus:border-brand focus:ring-2 focus:ring-brand/20";

  return (
    <div className="flex min-h-full items-center justify-center p-4">
      <div className="w-full max-w-md rounded-2xl bg-white p-8 shadow-lg">
        <Logo />
        <h1 className="mt-6 text-2xl font-bold">تسجيل الدخول</h1>
        <p dir="ltr" className="mt-1 text-start text-sm text-slate-500">{BRAND.product}</p>

        <form onSubmit={handleSubmit(onSubmit)} noValidate className="mt-6 space-y-4">
          {error && (
            <div role="alert" className="flex items-start gap-2 rounded-lg bg-red-50 p-3 text-sm text-red-700">
              <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}
          <div>
            <label htmlFor="username" className="mb-1 block text-sm font-medium">اسم المستخدم</label>
            <input id="username" dir="ltr" autoComplete="username" className={field} {...register("username")} />
            {errors.username && <p className="mt-1 text-xs text-red-600">{errors.username.message}</p>}
          </div>
          <div>
            <label htmlFor="password" className="mb-1 block text-sm font-medium">كلمة المرور</label>
            <div className="relative">
              <input
                id="password"
                dir="ltr"
                type={show ? "text" : "password"}
                autoComplete="current-password"
                className={`${field} pe-10`}
                {...register("password")}
              />
              <button
                type="button"
                onClick={() => setShow((s) => !s)}
                aria-label={show ? "إخفاء كلمة المرور" : "إظهار كلمة المرور"}
                className="absolute inset-y-0 end-2 flex items-center text-slate-400 hover:text-slate-600"
              >
                {show ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
              </button>
            </div>
            {errors.password && <p className="mt-1 text-xs text-red-600">{errors.password.message}</p>}
          </div>
          <button
            type="submit"
            disabled={isSubmitting}
            className="flex w-full items-center justify-center gap-2 rounded-lg bg-brand py-2.5 font-semibold text-white transition hover:bg-brand-dark disabled:opacity-60"
          >
            {isSubmitting && <Loader2 className="h-4 w-4 animate-spin" />}
            دخول
          </button>
        </form>
      </div>
    </div>
  );
}
