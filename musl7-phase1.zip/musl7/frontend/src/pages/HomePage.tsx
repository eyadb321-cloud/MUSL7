import { LogOut } from "lucide-react";
import { Logo } from "../components/Logo";
import { useAuth } from "../features/auth/AuthContext";

// صفحة مؤقتة تؤكد نجاح تسجيل الدخول. لوحة التحكم الفعلية في Phase 2.
export default function HomePage() {
  const { user, logout } = useAuth();
  return (
    <div className="mx-auto max-w-3xl p-6">
      <div className="flex items-center justify-between">
        <Logo />
        <button onClick={logout} className="flex items-center gap-2 rounded-lg border border-slate-300 px-3 py-2 text-sm hover:bg-white">
          <LogOut className="h-4 w-4" /> تسجيل الخروج
        </button>
      </div>
      <div className="mt-8 rounded-2xl bg-white p-6 shadow">
        <h1 className="text-xl font-bold">أهلاً {user?.full_name}</h1>
        <p className="mt-1 text-slate-600">الدور: {user?.role_name_ar}</p>
        <p className="mt-4 text-sm text-slate-500">تم تسجيل الدخول بنجاح. لوحة التحكم ستُبنى في المرحلة الثانية.</p>
      </div>
    </div>
  );
}
