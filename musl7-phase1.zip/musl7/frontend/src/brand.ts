// مصدر واحد لأسماء العلامة التجارية. الاسم الإنجليزي الوحيد المعتمد: MUSL7
export const BRAND = {
  ar: "مُصلِّح",
  en: "MUSL7",
  display: "مُصلِّح | MUSL7",
  product: "MUSL7 Home Maintenance Management System",
  assistant: "مساعد مُصلِّح",
} as const;
