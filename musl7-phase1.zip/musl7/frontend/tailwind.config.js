/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        brand: {
          ink: "#0F2A33",
          DEFAULT: "#0E7C86",
          dark: "#0A5F67",
          light: "#E3F3F4",
          accent: "#F2A33A",
        },
        surface: "#F6F8F9",
      },
      fontFamily: {
        sans: ["Cairo", "Segoe UI", "Tahoma", "Arial", "sans-serif"],
      },
    },
  },
  plugins: [],
};
