from functools import lru_cache

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    app_name: str = "MUSL7"
    secret_key: str = Field(min_length=32)  # مطلوب: لا توجد قيمة افتراضية
    database_url: str = "sqlite:///../database/musl7.db"
    access_token_expire_minutes: int = 480
    jwt_algorithm: str = "HS256"
    cors_origins: str = "http://localhost:5173"

    @property
    def cors_origin_list(self) -> list[str]:
        return [o.strip() for o in self.cors_origins.split(",") if o.strip()]


@lru_cache
def get_settings() -> Settings:
    return Settings()  # type: ignore[call-arg]
