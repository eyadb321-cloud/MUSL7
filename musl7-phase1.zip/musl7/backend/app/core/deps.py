import jwt
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy.orm import Session

from app.core.db import get_db
from app.core.security import decode_access_token
from app.models.user import User

_bearer = HTTPBearer(auto_error=False)


def _unauthorized() -> HTTPException:
    return HTTPException(
        status.HTTP_401_UNAUTHORIZED,
        "يجب تسجيل الدخول",
        headers={"WWW-Authenticate": "Bearer"},
    )


def get_current_user(
    creds: HTTPAuthorizationCredentials | None = Depends(_bearer),
    db: Session = Depends(get_db),
) -> User:
    if creds is None:
        raise _unauthorized()
    try:
        payload = decode_access_token(creds.credentials)
        user_id = int(payload["sub"])
    except (jwt.PyJWTError, KeyError, ValueError):
        raise _unauthorized()
    user = db.get(User, user_id)
    if user is None or not user.is_active or user.deleted_at is not None:
        raise _unauthorized()
    return user


def require_roles(*role_codes: str):
    """RBAC: السماح فقط للأدوار المحددة. يُستخدم في مراحل لاحقة."""

    def checker(user: User = Depends(get_current_user)) -> User:
        if user.role.code not in role_codes:
            raise HTTPException(status.HTTP_403_FORBIDDEN, "ليس لديك صلاحية لهذا الإجراء")
        return user

    return checker
