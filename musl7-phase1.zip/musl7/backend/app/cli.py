"""أوامر الإدارة:
    python -m app.cli init            # إنشاء الأدوار الأولية
    python -m app.cli create-owner --username owner --full-name "الاسم"
"""
import argparse
import getpass
import sys

from sqlalchemy import select

from app.core.db import SessionLocal
from app.core.security import hash_password
from app.models.user import Role, User

ROLES = [
    ("OWNER", "المالك", "صاحب الشركة - كل الصلاحيات"),
    ("ADMIN", "مدير النظام", "إدارة النظام والمستخدمين"),
    ("CUSTOMER_SERVICE", "خدمة العملاء", "العملاء والطلبات والمحادثات"),
    ("OPERATIONS", "العمليات", "المعاينات والتنفيذ والموردون"),
    ("ACCOUNTANT", "المحاسب", "الحسابات والتقارير المالية"),
]


def seed_roles(db) -> int:
    created = 0
    for code, name_ar, desc in ROLES:
        if db.scalar(select(Role).where(Role.code == code)) is None:
            db.add(Role(code=code, name_ar=name_ar, description=desc))
            created += 1
    db.commit()
    return created


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="app.cli")
    sub = p.add_subparsers(dest="cmd", required=True)
    sub.add_parser("init")
    o = sub.add_parser("create-owner")
    o.add_argument("--username", required=True)
    o.add_argument("--full-name", required=True)
    args = p.parse_args(argv)

    with SessionLocal() as db:
        n = seed_roles(db)
        if args.cmd == "init":
            print(f"تم. أدوار جديدة: {n}")
            return 0

        username = args.username.strip().lower()
        if db.scalar(select(User).where(User.username == username)):
            print("اسم المستخدم موجود بالفعل", file=sys.stderr)
            return 1
        pw = getpass.getpass("كلمة المرور (10 أحرف على الأقل): ")
        if len(pw) < 10 or pw != getpass.getpass("أعد كتابتها: "):
            print("كلمة المرور قصيرة أو غير متطابقة", file=sys.stderr)
            return 1
        owner = db.scalar(select(Role).where(Role.code == "OWNER"))
        db.add(User(username=username, full_name=args.full_name, password_hash=hash_password(pw), role_id=owner.id))
        db.commit()
        print("تم إنشاء حساب المالك")
        return 0


if __name__ == "__main__":
    raise SystemExit(main())
