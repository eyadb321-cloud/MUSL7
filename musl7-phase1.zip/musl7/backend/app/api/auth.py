from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.db import get_db
from app.core.deps import get_current_user
from app.core.security import DUMMY_HASH, create_access_token, verify_password
from app.models.user import User
from app.schemas.auth import LoginIn, TokenOut, UserOut
from app.services.activity import log_activity

router = APIRouter(prefix="/api/auth", tags=["auth"])


def _user_out(u: User) -> UserOut:
    return UserOut(
        id=u.id,
        username=u.username,
        full_name=u.full_name,
        role_code=u.role.code,
        role_name_ar=u.role.name_ar,
    )


@router.post("/login", response_model=TokenOut)
def login(payload: LoginIn, request: Request, db: Session = Depends(get_db)):
    username = payload.username.strip().lower()
    ip = request.client.host if request.client else None
    user = db.scalar(select(User).where(User.username == username, User.deleted_at.is_(None)))

    # نتحقق دائمًا من كلمة مرور (حقيقية أو صورية) لتقليل تسريب وجود المستخدم عبر الزمن
    password_ok = verify_password(payload.password, user.password_hash if user else DUMMY_HASH)

    if user is None or not password_ok or not user.is_active:
        log_activity(
            db,
            "auth.login_failed",
            user_id=user.id if user else None,
            details={"username": username},
            ip_address=ip,
        )
        db.commit()
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "اسم المستخدم أو كلمة المرور غير صحيحة")

    user.last_login_at = datetime.now(timezone.utc)
    log_activity(db, "auth.login", user_id=user.id, ip_address=ip)
    db.commit()
    return TokenOut(access_token=create_access_token(user.id, user.role.code), user=_user_out(user))


@router.get("/me", response_model=UserOut)
def me(user: User = Depends(get_current_user)):
    return _user_out(user)
