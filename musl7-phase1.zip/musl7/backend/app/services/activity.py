import json

from sqlalchemy.orm import Session

from app.models.user import ActivityLog


def log_activity(
    db: Session,
    action: str,
    user_id: int | None = None,
    entity_type: str | None = None,
    entity_id: str | int | None = None,
    details: dict | None = None,
    ip_address: str | None = None,
) -> None:
    """تسجيل عملية في activity_logs. لا تضع كلمات مرور أو أسرارًا في details."""
    db.add(
        ActivityLog(
            user_id=user_id,
            action=action,
            entity_type=entity_type,
            entity_id=str(entity_id) if entity_id is not None else None,
            details=json.dumps(details, ensure_ascii=False) if details else None,
            ip_address=ip_address,
        )
    )
