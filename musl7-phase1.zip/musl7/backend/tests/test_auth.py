from tests.conftest import PASSWORD


def _login(client, username="owner", password=PASSWORD):
    return client.post("/api/auth/login", json={"username": username, "password": password})


def test_health(client):
    assert client.get("/api/health").json()["status"] == "ok"


def test_login_success_returns_token_and_role(client):
    r = _login(client)
    assert r.status_code == 200
    body = r.json()
    assert body["access_token"] and body["user"]["role_code"] == "OWNER"
    assert "password" not in str(body).lower()


def test_login_username_is_case_insensitive(client):
    assert _login(client, "  OWNER ").status_code == 200


def test_login_wrong_password(client):
    assert _login(client, password="wrong").status_code == 401


def test_login_unknown_user_same_error(client):
    a, b = _login(client, "nobody"), _login(client, password="wrong")
    assert a.status_code == b.status_code == 401
    assert a.json() == b.json()


def test_inactive_user_rejected(client):
    assert _login(client, "off").status_code == 401


def test_me_requires_token(client):
    assert client.get("/api/auth/me").status_code == 401
    assert client.get("/api/auth/me", headers={"Authorization": "Bearer garbage"}).status_code == 401


def test_me_with_token(client):
    token = _login(client).json()["access_token"]
    r = client.get("/api/auth/me", headers={"Authorization": f"Bearer {token}"})
    assert r.status_code == 200 and r.json()["username"] == "owner"


def test_failed_login_is_logged(client):
    from app.core.db import SessionLocal
    from app.models import ActivityLog

    _login(client, password="nope")
    with SessionLocal() as db:
        assert db.query(ActivityLog).filter_by(action="auth.login_failed").count() >= 1
