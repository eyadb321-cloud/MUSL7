import os
import tempfile

_tmp = tempfile.mkdtemp(prefix="musl7_test_")
os.environ["SECRET_KEY"] = "test-secret-key-test-secret-key-0123456789"
os.environ["DATABASE_URL"] = f"sqlite:///{_tmp}/test.db"

import pytest  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

from app.cli import seed_roles  # noqa: E402
from app.core.db import SessionLocal, engine  # noqa: E402
from app.core.security import hash_password  # noqa: E402
from app.main import app  # noqa: E402
from app.models import Base, Role, User  # noqa: E402

PASSWORD = "correct-horse-battery"


@pytest.fixture(scope="session", autouse=True)
def _db():
    Base.metadata.create_all(engine)
    with SessionLocal() as db:
        seed_roles(db)
        role = db.query(Role).filter_by(code="OWNER").one()
        db.add(User(username="owner", full_name="مالك تجريبي", password_hash=hash_password(PASSWORD), role_id=role.id))
        db.add(
            User(username="off", full_name="موقوف", password_hash=hash_password(PASSWORD), role_id=role.id, is_active=False)
        )
        db.commit()
    yield
    engine.dispose()


@pytest.fixture()
def client():
    return TestClient(app)
