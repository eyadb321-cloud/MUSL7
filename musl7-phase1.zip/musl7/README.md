# مُصلِّح | MUSL7
**MUSL7 Home Maintenance Management System** — نظام داخلي لإدارة خدمات الصيانة المنزلية (مركز طهطا، سوهاج).

> الحالة: **Phase 1 (الأساس + تسجيل الدخول)**. باقي المراحل لم تُنفَّذ بعد (انظر "الحالة").

## المتطلبات
Python 3.11+ ، Node.js 20+ ، Git. لا Docker ولا خدمات مدفوعة.

## تشغيل الـBackend
```bash
cd backend
python -m venv .venv
# Windows:  .venv\Scripts\activate      Linux/Mac:  source .venv/bin/activate
pip install -r requirements.txt
cp ../.env.example .env     # Windows: copy ..\.env.example .env  (ثم عدّل SECRET_KEY)
alembic upgrade head
python -m app.cli init
python -m app.cli create-owner --username owner --full-name "اسمك"
uvicorn app.main:app --reload --port 8000
```
توثيق الـAPI: http://localhost:8000/docs

> ملف `.env.example` في جذر المشروع؛ يُنسخ إلى `backend/.env` ويجب توليد `SECRET_KEY` (32 حرفًا على الأقل) وإلا لن يعمل الـBackend.

## تشغيل الـFrontend
```bash
cd frontend
npm install
npm run dev      # http://localhost:5173
```

## الاختبارات
```bash
cd backend && pytest
```

## الحالة
- Phase 1: كُتب الكود (FastAPI + SQLAlchemy + Alembic + JWT/Argon2 + React RTL + صفحة Login). **لم يُشغَّل أو يُختبَر بعد** — راجع ملاحظات التسليم.
- Phases 2–8: لم تبدأ.

## الهوية
الاسم العربي: مُصلِّح — الاسم الإنجليزي الوحيد: **MUSL7** (مصدره `frontend/src/brand.ts`).
